# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import datetime
from django.contrib.auth.models import User
from django.db import models
class Grocery(models.Model):
     Grocery_id=models.AutoField(primary_key=True)
     user=models.CharField(max_length=30)
     grocery_expense_date= models.DateField( default=datetime.date.today)
     spent_money= models.IntegerField(default=0)
class Entertainment(models.Model):
     Entertainment_id=models.AutoField(primary_key=True)
     user=models.CharField(max_length=30)
     entertainment_expense_date= models.DateField( default=datetime.date.today)
     spent_money= models.IntegerField(default=0)
class Vehicle(models.Model):
     Vehicle_id=models.AutoField(primary_key=True)
     user=models.CharField(max_length=30)
     vehicle_expense_date= models.DateField( default=datetime.date.today)
     spent_money= models.IntegerField(default=0)
class Food(models.Model):
     Food_id=models.AutoField(primary_key=True)
     user=models.CharField(max_length=30)
     food_expense_date= models.DateField( default=datetime.date.today)
     spent_money= models.IntegerField(default=0)
class Parties(models.Model):
     Parties_id=models.AutoField(primary_key=True)
     user=models.CharField(max_length=30)
     parties_expense_date= models.DateField( default=datetime.date.today)
     spent_money= models.IntegerField(default=0)
class Miscellaneous(models.Model):
     Miscellaneous_id=models.AutoField(primary_key=True)
     user=models.CharField(max_length=30)
     miscellaneous_expense_date= models.DateField( default=datetime.date.today)
     spent_money= models.IntegerField(default=0)
