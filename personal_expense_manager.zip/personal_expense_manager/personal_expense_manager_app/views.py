from django.shortcuts import *
from django.contrib.auth import authenticate,login
from django.contrib.auth.models import User
from .models import *
from django.http import *
import datetime
def index(request):
	if request.method == 'POST':
		user=User()
		user.username=request.POST.get('username')
		user.email=request.POST.get('email')
		user.password=request.POST.get('password')
		user.save()
		template = loader.get_template('login.html')
    		context = {'success':1}
		return HttpResponse(template.render(context, request))
		
	else:
		success=0	
		template = loader.get_template('register.html')
    		context = {}
		return HttpResponse(template.render(context, request))

def home(request):
	template = loader.get_template('navbar.html')
    	context = {}
	return HttpResponse(template.render(context, request))

def login(request):
	if request.method == 'POST':
		try:
			
			user=User.objects.get(username=request.POST.get('username'))
			request.session['username']=request.POST.get('username')
			template = loader.get_template('categories.html')
    			context = {'success':1}
			return HttpResponse(template.render(context, request))	
		except:
			template = loader.get_template('login.html')
    			context = {'success':0}
			return HttpResponse(template.render(context, request))				
	else:
		template = loader.get_template('login.html')
    		context = {}
		return HttpResponse(template.render(context, request))
def category(request):
	
	if request.method == 'POST':
		if request.POST.get('dropdown')=="Grocery":
			grocery=Grocery(user=request.session['username'],grocery_expense_date=request.POST.get('spentdate'),spent_money=request.POST.get('spentmoney'))
			grocery.save()
			
		elif request.POST.get('dropdown')=="Entertainment":
			entertainment=Entertainment(user=request.session['username'],entertainment_expense_date=request.POST.get('spentdate'),spent_money=request.POST.get('spentmoney'))
			entertainment.save()
			
		elif request.POST.get('dropdown')=="Vehicle":
			vehicle=Vehicle(user=request.session['username'],vehicle_expense_date=request.POST.get('spentdate'),spent_money=request.POST.get('spentmoney'))
			vehicle.save()
			
		elif request.POST.get('dropdown')=="Food":
			food=Food(user=request.session['username'],food_expense_date=request.POST.get('spentdate'),spent_money=request.POST.get('spentmoney'))
			food.save()
			
		elif request.POST.get('dropdown')=="Parties":
			parties=Parties(user=request.session['username'],parties_expense_date=request.POST.get('spentdate'),spent_money=request.POST.get('spentmoney'))
			parties.save()
			
		else:
			miscellaneous=Miscellaneous(user=request.session['username'],miscellaneous_expense_date=request.POST.get('spentdate'),spent_money=request.POST.get('spentmoney'))
			miscellaneous.save()
			
	
	template = loader.get_template('categories.html')
	context = {}
	return HttpResponse(template.render(context, request))
def expenseslist(request):
	grocery=Grocery.objects.all()
	entertainment=Entertainment.objects.all()
	food=Food.objects.all()
	vehicle=Vehicle.objects.all()
	parties=Parties.objects.all()
	miscellaneous=Miscellaneous.objects.all()
	grocery_money=0
	entertainment_money=0
	food_money=0
	vehicle_money=0
	parties_money=0
	miscellaneous_money=0
	for obj in grocery:
		if obj.user==request.session['username']:
			grocery_money=grocery_money+obj.spent_money
	for obj in entertainment:
		if obj.user==request.session['username']:
			entertainment_money=entertainment_money+obj.spent_money
	for obj in food:
		if obj.user==request.session['username']:
			food_money=food_money+obj.spent_money
	for obj in vehicle:
		if obj.user==request.session['username']:
			vehicle_money=vehicle_money+obj.spent_money
	for obj in parties:
		if obj.user==request.session['username']:
			parties_money=parties_money+obj.spent_money
	for obj in miscellaneous:
		if obj.user==request.session['username']:
			miscellaneous_money=miscellaneous_money+obj.spent_money
	template = loader.get_template('expense_list.html')
	context = {'grocery_money':grocery_money,'entertainment_money':entertainment_money,'food_money':food_money,'vehicle_money':vehicle_money,'parties_money':parties_money,'miscellaneous_money':miscellaneous_money}
	return HttpResponse(template.render(context, request))
def dailyreport(request):
	grocery=Grocery.objects.all()
	entertainment=Entertainment.objects.all()
	food=Food.objects.all()
	vehicle=Vehicle.objects.all()
	parties=Parties.objects.all()
	miscellaneous=Miscellaneous.objects.all()
	grocery_money=0
	entertainment_money=0
	food_money=0
	vehicle_money=0
	parties_money=0
	miscellaneous_money=0
	for obj in grocery:
		if obj.user==request.session['username'] and str(obj.grocery_expense_date)==datetime.datetime.now().strftime ("%Y-%m-%d"):
			grocery_money=grocery_money+obj.spent_money
	for obj in entertainment:
		if obj.user==request.session['username'] and str(obj.entertainment_expense_date)==datetime.datetime.now().strftime ("%Y-%m-%d"):
			entertainment_money=entertainment_money+obj.spent_money
	for obj in food:
		if obj.user==request.session['username'] and str(obj.food_expense_date)==datetime.datetime.now().strftime ("%Y-%m-%d"):
			food_money=food_money+obj.spent_money
	for obj in vehicle:
		if obj.user==request.session['username'] and str(obj.vehicle_expense_date)==datetime.datetime.now().strftime ("%Y-%m-%d"):
			vehicle_money=vehicle_money+obj.spent_money
	for obj in parties:
		if obj.user==request.session['username'] and str(obj.parties_expense_date)==datetime.datetime.now().strftime ("%Y-%m-%d"):
			parties_money=parties_money+obj.spent_money
	for obj in miscellaneous:
		if obj.user==request.session['username'] and str(obj.miscellaneous_expense_date)==datetime.datetime.now().strftime ("%Y-%m-%d"):
			miscellaneous_money=miscellaneous_money+obj.spent_money
	template = loader.get_template('dailyreport.html')
	context ={'grocery_money':grocery_money,'entertainment_money':entertainment_money,'food_money':food_money,'vehicle_money':vehicle_money,'parties_money':parties_money,'miscellaneous_money':miscellaneous_money}
	return HttpResponse(template.render(context, request))
def monthlyreport(request):
	grocery=Grocery.objects.all()
	entertainment=Entertainment.objects.all()
	food=Food.objects.all()
	vehicle=Vehicle.objects.all()
	parties=Parties.objects.all()
	miscellaneous=Miscellaneous.objects.all()
	grocery_money=0
	entertainment_money=0
	food_money=0
	vehicle_money=0
	parties_money=0
	miscellaneous_money=0
	today = datetime.datetime.now().strftime ("%Y-%m-%d")
	year,month,date=today.split('-')
	for obj in grocery:
		if obj.user==request.session['username']:
			spent_date=str(obj.grocery_expense_date)
			spent_year,spent_month,expense_date=today.split('-')
			if spent_month==month:
				grocery_money=grocery_money+obj.spent_money
	for obj in entertainment:
		if obj.user==request.session['username']:
			spent_date=str(obj.entertainment_expense_date)
			spent_year,spent_month,expense_date=today.split('-')
			if spent_month==month:
				entertainment_money=entertainment_money+obj.spent_money
	for obj in food:
		if obj.user==request.session['username']:
			spent_date=str(obj.food_expense_date)
			spent_year,spent_month,expense_date=today.split('-')
			if spent_month==month:
				food_money=food_money+obj.spent_money
	for obj in vehicle:
		if obj.user==request.session['username']:
			spent_date=str(obj.vehicle_expense_date)
			spent_year,spent_month,expense_date=today.split('-')
			if spent_month==month:
				vehicle_money=vehicle_money+obj.spent_money
	for obj in parties:
		if obj.user==request.session['username']:
			spent_date=str(obj.parties_expense_date)
			spent_year,spent_month,expense_date=today.split('-')
			if spent_month==month:
				parties_money=parties_money+obj.spent_money
	for obj in miscellaneous:
		if obj.user==request.session['username']:
			spent_date=str(obj.miscellaneous_expense_date)
			spent_year,spent_month,expense_date=today.split('-')
			if spent_month==month:
				miscellaneous_money=miscellaneous_money+obj.spent_money
	
	

	template = loader.get_template('monthlyreport.html')
	context ={'grocery_money':grocery_money,'entertainment_money':entertainment_money,'food_money':food_money,'vehicle_money':vehicle_money,'parties_money':parties_money,'miscellaneous_money':miscellaneous_money}
	return HttpResponse(template.render(context, request))
	
			
	
	
