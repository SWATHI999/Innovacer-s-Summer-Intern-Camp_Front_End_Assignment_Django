from django.conf.urls import url
from . import views
app_name='personal_expense_manager_app'
urlpatterns = [
url(r'^home',views.home,name='home'),   
url(r'^login/$',views.login,name='login'),
url(r'^category/$',views.category,name='category'),
url(r'^index/$',views.index,name='index'),
url(r'^expenseslist/$',views.expenseslist,name='expenseslist'),
url(r'^dailyreport/$',views.dailyreport,name='dailyreport'),
url(r'^monthlyreport/$',views.monthlyreport,name='monthlyreport'),
    
]
